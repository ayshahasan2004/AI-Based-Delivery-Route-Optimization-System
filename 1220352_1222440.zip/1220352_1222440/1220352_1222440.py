# 🚚📦 Package Delivery Optimization: Genetic Algorithm & Simulated Annealing

import math
import random
import matplotlib.pyplot as plt
import time
from pathlib import Path

# --------------------------------------
# 📦 Classes
# --------------------------------------

class Package:
    """
    Represents a package to be delivered.
    Attributes:
        id (int): Unique identifier for the package.
        x (float): X-coordinate of the delivery location.
        y (float): Y-coordinate of the delivery location.
        weight (float): Weight of the package.
        priority (int): Priority level of the package (e.g., 1 = high).
    """
    def __init__(self, id, x, y, weight, priority):
        self.id = id
        self.x = x
        self.y = y
        self.weight = weight
        self.priority = priority

class Vehicle:
    """
    Represents a delivery vehicle.
    Attributes:
        id (int): Unique identifier for the vehicle.
        capacity (float): Maximum load capacity the vehicle can carry.
        assigned_packages (list): List of packages assigned to this vehicle.
    """
    def __init__(self, id, capacity):
        self.id = id
        self.capacity = capacity
        self.assigned_packages = []

# --------------------------------------
# 📏 Utilities
# --------------------------------------

def distance(x1, y1, x2, y2):
    """
    Calculates the Euclidean distance between two points (x1, y1) and (x2, y2).
    Used when coordinates are provided separately.
    """
    return math.sqrt((x1 - x2)**2 + (y1 - y2)**2)

def euclidean_distance(p1, p2):
    """
    Calculates the Euclidean distance between two points given as tuples.
    Used when coordinates are represented as (x, y) tuples.
    """
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

# --------------------------------------
# 📂 Data Reading
# --------------------------------------

BASE_DIR = Path(__file__).resolve().parent  # Directory where the current script is located

def read_packages(filename):
    """
    Reads package data from a text file and returns a list of Package objects.
    Each line in the file should contain: id x y weight priority
    Args:
        filename (str): Name of the package data file.
    Returns:
        list[Package]: List of Package instances.
    """
    path = BASE_DIR / filename
    packages = []
    with open(path, 'r') as file:
        for line in file:
            id, x, y, weight, priority = map(int, line.strip().split())
            packages.append(Package(id, x, y, weight, priority))
    return packages

def read_vehicles(filename):
    """
    Reads vehicle data from a text file and returns a list of Vehicle objects.
    Each line in the file should contain: id capacity
    Args:
        filename (str): Name of the vehicle data file.
    Returns:
        list[Vehicle]: List of Vehicle instances.
    """
    path = BASE_DIR / filename
    vehicles = []
    with open(path, 'r') as file:
        for line in file:
            id, capacity = map(int, line.strip().split())
            vehicles.append(Vehicle(id, capacity))
    return vehicles
# --------------------------------------
# 🧬 Genetic Algorithm Functions
# --------------------------------------

def generate_initial_population(packages, vehicles, population_size):
    """
    Generates an initial population of delivery solutions.
    Each solution maps vehicles to lists of packages, ensuring capacity constraints.
    Packages are prioritized by their priority level (lower number = higher priority).
    A warning is printed if a package exceeds all vehicle capacities.
    
    Args:
        packages (list[Package]): List of all available packages.
        vehicles (list[Vehicle]): List of delivery vehicles.
        population_size (int): Number of solutions in the initial population.
    
    Returns:
        list[dict[int, list[Package]]]: List of individual solutions.
    """
    population = []
    warned_packages = set()  # ✅ Prevent repeated warnings for the same package

    for _ in range(population_size):
        solution = {v.id: [] for v in vehicles}
        vehicle_weights = {v.id: 0 for v in vehicles}
        sorted_packages = sorted(packages, key=lambda p: p.priority)

        for pkg in sorted_packages:
            # Skip packages that exceed all vehicle capacities
            if all(pkg.weight > v.capacity for v in vehicles):
                if pkg.id not in warned_packages:
                    print(f"🚫 Package {pkg.id} (weight={pkg.weight}) exceeds all vehicle capacities.")
                    warned_packages.add(pkg.id)
                continue

            # Try assigning the package to a random vehicle with available capacity
            placed = False
            random.shuffle(vehicles)
            for v in vehicles:
                if vehicle_weights[v.id] + pkg.weight <= v.capacity:
                    solution[v.id].append(pkg)
                    vehicle_weights[v.id] += pkg.weight
                    placed = True
                    break

        population.append(solution)
    return population


def fitness(solution):
    """
    Calculates the fitness score for a given solution.
    The score favors high-priority and high-weight deliveries while minimizing distance.
    
    Returns:
        float: Fitness score of the solution.
    """
    total_score = 0
    for v_id, pkgs in solution.items():
        total_weight = sum(p.weight for p in pkgs)
        total_priority = sum(p.priority for p in pkgs)
        total_distance = sum(distance(0, 0, p.x, p.y) for p in pkgs)
        score = (total_priority * 10) + total_weight - total_distance * 0.1
        total_score += score
    return total_score


def tournament_selection(population, tournament_size=3):
    """
    Selects a parent solution from the population using tournament selection.
    
    Args:
        population (list): List of solutions.
        tournament_size (int): Number of individuals competing in the tournament.
    
    Returns:
        dict: The solution with the highest fitness among competitors.
    """
    competitors = random.sample(population, tournament_size)
    return max(competitors, key=fitness)


def crossover(parent1, parent2, vehicles):
    """
    Performs crossover between two parent solutions to generate offspring.
    Tries to preserve valid assignments while reassigning packages randomly.
    
    Args:
        parent1 (dict): First parent solution.
        parent2 (dict): Second parent solution.
        vehicles (list[Vehicle]): List of vehicles.
    
    Returns:
        tuple: Two offspring solutions.
    """
    all_packages = []
    for pkgs in parent1.values():
        all_packages.extend(pkgs)
    random.shuffle(all_packages)

    def assign_packages_randomly(source_parent):
        child = {v.id: [] for v in vehicles}
        vehicle_weights = {v.id: 0 for v in vehicles}
        assigned = set()

        # Try assigning packages from the source parent first
        for v_id, pkgs in source_parent.items():
            for pkg in pkgs:
                if pkg.id in assigned:
                    continue
                if vehicle_weights[v_id] + pkg.weight <= [v for v in vehicles if v.id == v_id][0].capacity:
                    child[v_id].append(pkg)
                    vehicle_weights[v_id] += pkg.weight
                    assigned.add(pkg.id)

        # Assign remaining packages randomly
        for pkg in all_packages:
            if pkg.id in assigned:
                continue
            for v in vehicles:
                if vehicle_weights[v.id] + pkg.weight <= v.capacity:
                    child[v.id].append(pkg)
                    vehicle_weights[v.id] += pkg.weight
                    assigned.add(pkg.id)
                    break
        return child

    return assign_packages_randomly(parent1), assign_packages_randomly(parent2)


def mutate(solution, vehicles, mutation_rate=0.05):
    """
    Randomly transfers packages between vehicles to introduce variation.
    
    Args:
        solution (dict): A solution to mutate.
        vehicles (list[Vehicle]): List of vehicles.
        mutation_rate (float): Probability of mutating a package.
    
    Returns:
        dict: Mutated solution.
    """
    new_solution = {v_id: list(pkgs) for v_id, pkgs in solution.items()}
    vehicle_weights = {v.id: sum(pkg.weight for pkg in new_solution[v.id]) for v in vehicles}
    
    for v_from in vehicles:
        for pkg in list(new_solution[v_from.id]):
            if random.random() < mutation_rate:
                v_to = random.choice(vehicles)
                if v_to.id != v_from.id and vehicle_weights[v_to.id] + pkg.weight <= v_to.capacity:
                    new_solution[v_from.id].remove(pkg)
                    new_solution[v_to.id].append(pkg)
                    vehicle_weights[v_from.id] -= pkg.weight
                    vehicle_weights[v_to.id] += pkg.weight
    return new_solution


def genetic_algorithm(packages, vehicles, population_size=50, generations=500, mutation_rate=0.05):
    """
    Runs the genetic algorithm to find an optimized delivery assignment.
    
    Args:
        packages (list[Package]): List of packages.
        vehicles (list[Vehicle]): List of vehicles.
        population_size (int): Number of solutions per generation.
        generations (int): Number of generations to evolve.
        mutation_rate (float): Rate at which mutations occur.
    
    Returns:
        tuple: Best solution found and its fitness score.
    """
    population = generate_initial_population(packages, vehicles, population_size)
    
    best_solution = max(population, key=fitness)
    best_fitness = fitness(best_solution)

    for _ in range(generations):
        new_population = []
        while len(new_population) < population_size:
            parent1 = tournament_selection(population)
            parent2 = tournament_selection(population)
            child1, child2 = crossover(parent1, parent2, vehicles)
            child1 = mutate(child1, vehicles, mutation_rate)
            child2 = mutate(child2, vehicles, mutation_rate)
            new_population.extend([child1, child2])
        
        population = new_population[:population_size]
        current_best = max(population, key=fitness)
        if fitness(current_best) > best_fitness:
            best_solution = current_best
            best_fitness = fitness(current_best)

    return best_solution, best_fitness



# --------------------------------------
# ❄️ Simulated Annealing Functions
# --------------------------------------

# Calculate the Euclidean distance between two (x, y) locations
def euclidean_distance(loc1, loc2):
    return ((loc1[0] - loc2[0])**2 + (loc1[1] - loc2[1])**2) ** 0.5


# Cost function to evaluate a solution based on route distances and package priorities
def sa_cost_function(solution, shop_location=(0, 0)):
    total_cost = 0
    for vehicle_route in solution:
        if not vehicle_route:
            continue  # Skip empty routes

        # Start calculating route distance: from shop to first package
        route_distance = euclidean_distance(shop_location, vehicle_route[0]['location'])

        # Add distances between consecutive packages in the route
        for i in range(len(vehicle_route) - 1):
            route_distance += euclidean_distance(vehicle_route[i]['location'], vehicle_route[i+1]['location'])

        # Return to shop from last package
        route_distance += euclidean_distance(vehicle_route[-1]['location'], shop_location)

        # Calculate a reward based on delivery priority (lower number = higher priority)
        priority_score = 0
        for pkg in vehicle_route:
            # Packages with higher priority (e.g., priority 1) get more reward (25), lower priority less
            priority_score += (6 - pkg['priority']) * 5

        # Total cost for vehicle = route distance - (priority reward weighted)
        vehicle_cost = route_distance - priority_score * 0.2
        total_cost += vehicle_cost

    return total_cost


# Create an initial solution by distributing packages across vehicles
def initial_solution(packages, vehicles):
    solution = [[] for _ in range(1, len(vehicles) + 1)]  # One list per vehicle

    # Optional: sort packages by priority (ascending = high priority first)
    packages = sorted(packages, key=lambda p: p['priority'])

    for pkg in packages:
        # Skip any package that cannot be carried by any vehicle
        if all(pkg['weight'] > v['capacity'] for v in vehicles):
            print(f"🚫 Package {pkg['id']} exceeds the capacity of all vehicles.")
            continue

        # Find the vehicle with enough remaining capacity and least current load
        best_idx, min_load = None, float('inf')
        for i, v in enumerate(vehicles):
            current_load = sum(p['weight'] for p in solution[i])
            if current_load + pkg['weight'] <= v['capacity'] and current_load < min_load:
                best_idx = i
                min_load = current_load

        # Assign the package to the best vehicle (if found)
        if best_idx is not None:
            solution[best_idx].append(pkg)

    return solution


# Generate a neighboring solution by moving high-priority packages between vehicles
def get_neighbor(current_solution, vehicles):
    # Deep copy the current solution
    new_solution = [list(route) for route in current_solution]
    
    # Flatten all packages and sort by priority (ascending = highest priority first)
    all_packages = [pkg for route in current_solution for pkg in route]
    all_packages.sort(key=lambda p: p['priority'])

    # Try to relocate each package (starting with highest priority)
    for pkg in all_packages:
        from_idx = next(i for i, route in enumerate(current_solution) if pkg in route)
        new_solution[from_idx].remove(pkg)  # Temporarily remove package

        # Attempt to move it to another vehicle with enough capacity
        for to_idx in range(len(vehicles)):
            if sum(p['weight'] for p in new_solution[to_idx]) + pkg['weight'] <= vehicles[to_idx]['capacity']:
                new_solution[to_idx].append(pkg)
                break
        else:
            # If no suitable vehicle found, return the package to original position
            new_solution[from_idx].append(pkg)

    return new_solution


# Simulated Annealing algorithm to optimize package distribution among vehicles
def simulated_annealing(vehicles, packages, initial_temp, cooling_rate, iterations):
    # Step 1: Generate an initial feasible solution
    current_solution = initial_solution(packages, vehicles)
    best_solution = current_solution
    best_score = -sa_cost_function(current_solution)  # We negate cost to treat it as a score (higher is better)

    temperature = initial_temp

    for _ in range(iterations):
        # Step 2: Generate a neighboring solution
        neighbor = get_neighbor(current_solution, vehicles)
        neighbor_score = -sa_cost_function(neighbor)

        # Step 3: Decide whether to accept the neighbor
        if neighbor_score > best_score or math.exp((neighbor_score - best_score) / temperature) > random.random():
            current_solution = neighbor
            best_score = neighbor_score
            best_solution = neighbor

        # Step 4: Reduce temperature according to the cooling schedule
        temperature *= cooling_rate

    return best_solution

# --------------------------------------
# 🎨 Visualization
# --------------------------------------

# Function to visualize the solution generated by a Genetic Algorithm
def visualize_solution(solution):
    colors = ['red', 'blue', 'green', 'purple', 'orange', 'cyan', 'magenta']
    depot = (0, 0)  # Central depot location
    plt.figure(figsize=(8, 8))
    plt.title("Genetic Algorithm - Package Delivery Paths")
    plt.xlabel("X")
    plt.ylabel("Y")

    # Iterate over each vehicle and its assigned packages
    for idx, (v_id, pkgs) in enumerate(solution.items()):
        color = colors[idx % len(colors)]  # Assign color to each vehicle route
        coords = [depot] + [(p.x, p.y) for p in pkgs] + [depot]  # Path: depot → all packages → depot
        draw_vehicle_path(coords, color, f"Vehicle {v_id}")  # Draw the path

        # Annotate each package with its ID on the plot
        for p in pkgs:
            plt.text(p.x + 0.5, p.y + 0.5, f"{p.id}", fontsize=8, color=color)

    # Mark the depot
    plt.scatter(*depot, c='black', marker='X', s=100, label="Depot (50,50)")
    plt.legend()
    plt.grid(True)
    plt.show()


# Helper function to draw a path for a vehicle using coordinates
def draw_vehicle_path(coords, color, label=None):
    x, y = zip(*coords)  # Unpack coordinates into x and y lists
    plt.plot(x, y, color=color, marker='o', label=label)  # Plot line with markers
# Function to visualize the solution generated by Simulated Annealing
def visualize_sa_solution(solution):
    colors = ['red', 'blue', 'green', 'purple', 'orange', 'cyan', 'magenta']
    depot = (0, 0)
    plt.figure(figsize=(8, 8))
    plt.title("Simulated Annealing - Vehicle Paths")
    plt.xlabel("X")
    plt.ylabel("Y")

    # Iterate over each vehicle route
    for idx, route in enumerate(solution):
        if not route:
            continue  # Skip if the route is empty
        color = colors[idx % len(colors)]  # Assign color
        coords = [depot] + [pkg['location'] for pkg in route] + [depot]  # Create full path
        draw_vehicle_path(coords, color, f"Vehicle {idx}")  # Draw the path

        # Annotate each package location with its ID
        for pkg in route:
            x, y = pkg['location']
            plt.text(x + 0.5, y + 0.5, f"{pkg['id']}", fontsize=8, color=color)

    # Draw the depot
    plt.scatter(*depot, c='black', marker='X', s=100, label="Depot (0,0)")
    plt.legend()
    plt.grid(True)
    plt.show()


# --------------------------------------
# 🚀 Main Program
# --------------------------------------
def main():
    # Load package and vehicle data from text files
    packages = read_packages('packages.txt')
    vehicles = read_vehicles('vehicles.txt')

    # Keep running until the user chooses to exit
    while True:
        print("\nSelect the solving method:")
        print("1. Genetic Algorithm")
        print("2. Simulated Annealing")
        print("3. Exit")

        # Get the user's choice
        choice = input("Enter your choice: ")

        # 🧬 Option 1: Genetic Algorithm
        if choice == "1":
            start_time = time.time()  # Start timing
            best_solution, best_fitness = genetic_algorithm(packages, vehicles)  # Run GA
            end_time = time.time()  # End timing

            print(f"✅ Best fitness: {best_fitness}")
            print(f"🕒 Time taken: {end_time - start_time:.2f} seconds")

            # Print the solution: which vehicle carries which packages
            for v_id, pkgs in best_solution.items():
                print(f"\n🚛 Vehicle {v_id} carries packages:")
                for p in pkgs:
                    print(f"   📦 Package {p.id}: Location=({p.x}, {p.y}), Weight={p.weight}, Priority={p.priority}")

            # Visualize the GA solution on a 2D map
            visualize_solution(best_solution)

        # 🔥 Option 2: Simulated Annealing
        if choice == "2":
            # Convert objects into dictionaries for the SA algorithm
            packages_sa = [{'id': p.id, 'location': (p.x, p.y), 'weight': p.weight, 'priority': p.priority} for p in packages]
            vehicles_sa = [{'id': v.id, 'capacity': v.capacity} for v in vehicles]

            # Set parameters for Simulated Annealing
            initial_temp = 1000        # Initial temperature
            cooling_rate = 0.995       # Cooling factor
            iterations = 1000          # Number of iterations

            # Run the SA algorithm
            start_time = time.time()
            best_solution = simulated_annealing(vehicles_sa, packages_sa, initial_temp, cooling_rate, iterations)
            best_cost = sa_cost_function(best_solution)  # Calculate cost of final solution
            end_time = time.time()

            print(f"✅ Best total cost: {best_cost}")
            print(f"🕒 Time taken: {end_time - start_time:.2f} seconds")

            # Print the SA solution: which vehicle carries which packages
            for idx, route in enumerate(best_solution):
                print(f"\n🚛 Vehicle {idx+1} carries packages:")
                for pkg in route:
                    x, y = pkg['location']
                    print(f"   📦 Package {pkg['id']}: Location=({x}, {y}), Weight={pkg['weight']}, Priority={pkg['priority']}")

            # Visualize the SA solution on a 2D map
            visualize_sa_solution(best_solution)

        # ❌ Option 3: Exit
        elif choice == "3":
            print("Exiting the program. Goodbye!")
            break

        # Handle invalid input
        else:
            print("❌ Invalid choice, please try again.")

# Make sure the main function runs when the script is executed
if __name__ == "__main__":
    main()

